# PROJECT STATUS — STORE.SLN PROJE DURUMU
# ═══════════════════════════════════════════════
# Projenin güncel fazı, teknik borçlar, yol haritası ve mimari kararları tanımlar.
# Antigravity, öncelikleri belirlerken ve raporlama yaparken bu dosyaya başvurur.
#
# Son Güncelleme: 23 Eylül 2026

---

## 1. GÜNCEL FAZ

**Aktif Faz:** Faz 2 — İş Mantığı Tamamlama

Faz 1 (Acil Güvenlik) henüz tam tamamlanmadı; güvenlik borçları devam ederken Faz 2 işleri paralel yürütülüyor.

---

## 2. TEKNİK BORÇ TAKİP TABLOSU

| # | Seviye | Konu | Detay | Durum |
|:--|:---:|:---|:---|:---|
| 1 | 🔴 KRİTİK | SSL Bypass | `Store.Catalog` ve `Store.WebUI`'da `ServerCertificateCustomValidationCallback => true` mevcut | ✅ ÇÖZÜLDÜ |
| 2 | 🔴 KRİTİK | Açık Metin Sırlar | `appsettings.json` dosyalarında DB şifreleri plaintext | ✅ ÇÖZÜLDÜ |
| 3 | 🔴 KRİTİK | KVKK — IdentityNumber | `IdentityNumber` (T.C. Kimlik No) veritabanında şifresiz | ❌ AÇIK |
| 4 | 🔴 KRİTİK | tempkey.jwk | IdentityServer token imzalama anahtarı `.gitignore`'da olmalı | ✅ ÇÖZÜLDÜ |
| 5 | 🟡 YÜKSEK | Rental İş Akışı | `PriceType.Rental(3)` ve `WholeRental(5)` tanımlı ama iş akışı kodlanmadı | ✅ ÇÖZÜLDÜ |
| 6 | 🟡 YÜKSEK | API Gateway Eksikliği | YARP/Ocelot yok; WebUI her servise doğrudan HTTP yapıyor | ❌ AÇIK |
| 7 | 🟡 YÜKSEK | Mesajlaşma Yok | Servisler arası asenkron iletişim (RabbitMQ/MassTransit) yok | ❌ AÇIK |
| 8 | 🔵 ORTA | Sıfır Test | Yalnızca `Store.Location.Tests`'te 7 birim test var | ❌ AÇIK |
| 9 | 🔵 ORTA | Discount Coupon İndeksi | `Code` alanı `NVARCHAR(MAX)`, `IsActive` üzerinde index yok | ✅ ÇÖZÜLDÜ |
| 10 | 🔵 ORTA | Order Namespace Hatası | `Entitties` (çift t) namespace/klasör adı | ✅ ÇÖZÜLDÜ |
| 11 | ✅ ÇÖZÜLDÜ | Catalog → Location Bağımlılığı | `Store.Shared.Enums` kullanımıyla çözüldü (15.09.2026) | ✅ KAPALI |
| 12 | ✅ ÇÖZÜLDÜ | Dealer B2B Ayrımı | `DealerFinancial` entity'si `Store.B2B`'ye taşındı | ✅ KAPALI |
| 13 | ✅ ÇÖZÜLDÜ | InstagramPost BsonSerializationException | Duplicate `IsActive` property kaldırıldı | ✅ KAPALI |
| 14 | ✅ ÇÖZÜLDÜ | InstagramPost AutoMapper | `GeneralMapping.cs`'ye mapping profilleri eklendi | ✅ KAPALI |
| 15 | 🔴 KRİTİK | UsersController Güvenliği | `UsersController`'dan `[AllowAnonymous]` kısımlarının kaldırılıp doğru `[Authorize]` politikasının yazılması | ✅ ÇÖZÜLDÜ |
| 16 | 🟡 YÜKSEK | UI Favori Ekleme Hatası | `/Default/Index` sayfasında ürün üzerindeki kalp butonu ile favoriye ekleme/çıkarma işlemi (favorite.js) düzgün çalışmıyor, askıya alındı. | ❌ AÇIK |

---

## 3. SON TAMAMLANAN İŞLER (16.09.2026)

| İş | Tarih | Detay |
|:---|:---|:---|
| Rental (Kiralama) Modülü | 02.10.2026 | Store.Rental mikroservisi, CQRS, Conflict Check iş mantığı, WebUI Arayüzü eklendi |
| Güvenlik & KVKK Yamaları | 02.10.2026 | appsettings.json plaintext şifre temizliği, AES-256 TCKimlik şifreleme, UsersController yetkilendirme (Authorize) kapatıldı |
| Instagram Akışı (Tam Modül) | 16.09.2026 | Entity, API, Service, Controller, Refit, Admin CRUD, Otomatik Medya Çekme |
| Instagram Otomasyon | 16.09.2026 | FetchInstagramMedia endpoint, og:image scraping, otomatik OrderIndex |
| AutoMapper Fix | 16.09.2026 | InstagramPost mapping profilleri eklendi |
| Agentic System v2.0 | 16.09.2026 | Agent_Gravity.md + 5 hafıza dokümanı oluşturuldu |

---

## 4. STRATEJİK YOL HARİTASI

### 🔴 Faz 1 — Acil Güvenlik & Teknik Borç Temizliği
1. ✅ SSL bypass kodlarının `#if DEBUG` ile sınırlandırılması
2. ✅ `appsettings.json` bağlantı cümleciklerinin `dotnet user-secrets`'e taşınması (Hazırlığı)
3. ❌ `IdentityNumber` alanının veritabanı seviyesinde şifrelenmesi (Kod incelemesinde plaintext olduğu tespit edildi)
4. ✅ `tempkey.jwk` dosyasının `.gitignore`'a eklenmesi
5. ✅ `UsersController` içerisindeki `[AllowAnonymous]` zafiyetinin kapatılıp yetkilendirmenin sağlanması

### 🟡 Faz 2 — İş Mantığı Tamamlama
1. ✅ **Rental (Kiralama) İş Akışı** — Stok takvimi, çakışma kontrolü, kira hesaplama, mikroservis
2. ✅ **Instagram Akışı** — Admin Panel'den Instagram gönderi yönetimi (16.09.2026)
3. ❌ **B2B Admin Ekranları** — Bayi Finans Yönetimi WebUI ekranları
4. ❌ **Server-Side DataTables** — Tüm yüksek hacimli ekranlara yayılması
5. ✅ **Favorite Modülü** — Standalone mikroservis olarak kurulması (28.09.2026)
6. ✅ **IdentityServer Login Entegrasyonu** — WebUI'da `UyelikController.Login` içerisinden token alınarak oturum açılması (TAMAMLANDI)

### 🔵 Faz 3 — Altyapı & DevOps Olgunlaşması
1. ❌ YARP / Ocelot API Gateway
2. ❌ RabbitMQ / MassTransit asenkron mesajlaşma
3. ❌ Redis Cache (sık erişilen katalog verileri)
4. ❌ Docker & Container (tüm servislerin container'da çalışması)
5. ❌ Test kapsamı artırma (xUnit, Testcontainers)

---

## 5. MİMARİ KARAR KAYITLARI (ADR — Architecture Decision Records)

### ADR-001: Favorite Servisi Standalone Mikroservis Olacak (16.09.2026)
- **Karar:** Catalog'a gömmek yerine bağımsız `Store.Favorite` mikroservisi oluşturulacak
- **Neden:** Bounded Context ayrımı; farklı okuma/yazma yükü; bağımsız ölçeklenebilirlik
- **Alternatif:** Catalog MongoDB'sine koleksiyon olarak eklemek (reddedildi)
- **Durum:** ✅ Onaylandı, 🔧 Geliştirmede

### ADR-002: Instagram Medya Çekme — Sadece Kapak Resmi (16.09.2026)
- **Karar:** Instagram gönderisinden yalnızca `og:image` (kapak resmi) çekilecek
- **Neden:** Instagram API erişimi gerektirmeden çalışır; karousel/video desteği karmaşıklık yaratır
- **Alternatif:** Tüm medyaları çekmek (reddedildi — Instagram bot koruması)
- **Durum:** ✅ Onaylandı, ✅ Tamamlandı

### ADR-003: BaseEntity'den Kalıtım Zorunluluğu (15.09.2026)
- **Karar:** Tüm entity'ler `Store.Shared.Entities.BaseEntity`'den türeyecek
- **Neden:** Audit trail, soft-delete ve tutarlı ID yönetimi
- **Alternatif:** Her servis kendi BaseEntity'sini tanımlasın (reddedildi — kod tekrarı)
- **Durum:** ✅ Onaylandı, ✅ Uygulandı

---

> **Güncelleme Kuralı:** Bir faz tamamlandığında, teknik borç kapandığında veya mimari karar alındığında bu doküman güncellenir.
