# ERROR RECOVERY

## Build/Test failure

`CAPTURE → CLASSIFY → ROOT CAUSE → MINIMAL FIX → RE-RUN → LIMIT → ESCALATE`

## Tekrarlama sınırı

Aynı hata için sınırsız deneme yapılmaz. Üç başarısız anlamlı düzeltmeden sonra görev `ESCALATED` olur ve yeni karar/inceleme gerekir.

## Rollback

Destructive veya geniş kapsamlı değişikliklerde implementasyon öncesi geri dönüş planı belirtilir.
