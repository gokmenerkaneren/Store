# WEEKLY ENGINEERING GOVERNANCE

## Döngü

`OBSERVE → AUDIT → CLASSIFY → PLAN → REMEDIATE → VERIFY → DOCUMENT → GOVERNANCE UPDATE`

## Review başlıkları

Architecture, Business Rules, Database, Security, Tests, Technical Debt, Documentation Drift ve Agent Governance.

## Agent sistemi güncellemesi

Bir haftalık review yeni bir governance kuralı öneriyorsa doğrudan yazılmaz. Proposal + impact analysis + review + approval + versioning uygulanır.
