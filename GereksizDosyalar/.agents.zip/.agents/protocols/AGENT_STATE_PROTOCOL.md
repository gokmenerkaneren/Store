# Agent State Protocol (Ajan Durum Modeli)

## Amaç
Orkestratörün (Agent_Gravity) projede aynı anda çalışan (veya birbirini bekleyen) alt ajanların durumlarını (state) anlık olarak takip edebilmesi ve tıkanıklıkları (bottleneck) tespit edebilmesidir.

## Ajan Durumları (Agent States)

Ajanlar görev esnasında şu durumlardan birinde olmalıdır:

- `IDLE`: Ajanın şu an aktif bir görevi yoktur. Bekleme halindedir.
- `ACTIVATING`: Ajan orkestratör tarafından göreve çağrılmıştır, Context dosyalarını okumaktadır.
- `ANALYZING`: Ajan problemi analiz etmektedir (Kod okuma, Search).
- `IMPLEMENTING`: Ajan aktif olarak kod, yapılandırma veya doküman yazmaktadır.
- `VERIFYING`: Ajan yazdığı kodu veya mimariyi doğrulamaktadır (Derleme, test koşma, Evidence toplama).
- `WAITING_FOR_HANDOFF`: Ajan topu başka bir uzmana atmıştır, ondan gelecek sonucu (handoff) beklemektedir. (Örn: Architect, DBA'in şema onayını beklerken).
- `WAITING_FOR_DECISION`: Ajan bir kuralda çelişki (Conflict) yaşamış ve Kullanıcı / Orkestratör kararını beklemektedir.
- `BLOCKED`: Ajan dışsal bir hata (Örn: tool hatası, dosya okuma izni hatası, loop protection limit aşımı) nedeniyle kilitlenmiştir.
- `FAILED`: Ajan görevi başaramamıştır (Örn: Evidence sağlayamamıştır) ve görevi bırakmıştır.
- `COMPLETED`: Ajan görevi `EVIDENCE_PROTOCOL` kurallarına uyarak başarıyla kapatmıştır.

## Orkestratör Kullanım Kuralı
- Paralel görevlerde, Agent_Gravity hangi ajanın hangi `State`'te olduğunu özetleyebilmelidir.
- Bir ajan `BLOCKED` veya `FAILED` durumuna geçerse, doğrudan `ERROR_RECOVERY.md` süreci işletilir.
- Bir ajan `WAITING_FOR_DECISION` durumuna geçerse, doğrudan `DECISION_SCHEMA.md` formatında kullanıcıdan onay istenir.
