# Error Recovery & Failure Classification (Hata Yönetimi ve Sınıflandırma)

## Amaç
Bir hata meydana geldiğinde ajanların "Hata oldu, tekrar deniyorum" döngüsüne girmesini engellemek; bunun yerine hatanın türünü (Classification) belirleyip doğru çözüm yolunu (veya doğru ajanı) seçmelerini sağlamaktır.

## Hata Sınıflandırması (Failure Classification)

Hatalar aşağıdaki kategorilerden birine atanmalı ve çözümü ona göre aranmalıdır:

1. **CODE_DEFECT (Kod Hatası):**
   - *Durum:* Derleme (Build) hatası, sözdizimi hatası, yanlış interface uygulaması.
   - *Aksiyon:* Hata, kodu yazan ajana (Örn: Architect veya BA) Evidence çıktısıyla geri gönderilir. Kod düzeltilir.

2. **TEST_DEFECT (Test/MANTIK Hatası):**
   - *Durum:* Kod derleniyor ancak Unit/Integration testi başarısız oluyor. İş mantığı yanlış.
   - *Aksiyon:* Business Analyst'e veya ilgili iş kuralını uygulayan ajana gönderilir. Mantık düzeltilir veya Test Engineer'ın testi hatalıysa test düzeltilir.

3. **ENVIRONMENT_FAILURE (Çevre/Araç Hatası):**
   - *Durum:* Veritabanına bağlanılamıyor, dosya okunamıyor, araç (tool) çalışmıyor.
   - *Aksiyon:* Orkestratör tarafından doğrudan size (Kullanıcıya) raporlanır. Kodda tekrar (retry) yapılmaz.

4. **GOVERNANCE_ERROR (Yönetişim/Kural Çakışması):**
   - *Durum:* Yapılan değişiklik `ARCHITECTURE.md` veya `BUSINESS_RULES.md` içindeki bir kuralı açıkça ihlal ediyor.
   - *Aksiyon:* Agent_Gravity değişikliği bloke eder (`BLOCKED` State) ve iptal eder. Ajanı uyararak baştan tasarım ister.

5. **MISSING_CONTEXT (Eksik Bağlam):**
   - *Durum:* Ajan, eksik bağlam yüzünden halüsinasyon görüyor veya projede olmayan bir sınıf kullanıyor.
   - *Aksiyon:* Orkestratör, ajanın Context Profile'ını (`CONTEXT_LOADING_PROTOCOL.md`) genişleterek görevi baştan verir.

## Hata Çözüm Döngüsü

`CAPTURE (Yakala) → CLASSIFY (Sınıflandır) → ROOT CAUSE (Kök Neden) → MINIMAL FIX (Minimal Düzeltme) → RE-RUN (Yeniden Çalıştır) → LIMIT (Limit Kontrolü) → ESCALATE (Kullanıcıya Taşı)`

## Tekrarlama Sınırı (Loop Protection Entegrasyonu)
Aynı hata tipi (`CODE_DEFECT` vb.) art arda `MAX_AGENT_RETRY = 2` kez düzeltilemiyorsa, görev kilitlenir (`BLOCKED`) ve doğrudan Kullanıcı (Gökmen) bilgilendirilir.
