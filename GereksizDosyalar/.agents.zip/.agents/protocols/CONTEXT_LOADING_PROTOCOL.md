# Context Loading Protocol (Bağlam Yükleme Stratejisi)

## Amaç
Tüm ajanların her görevde on binlerce satırlık belgeyi baştan sona okuması (context overhead ve token israfı) engellenmelidir. Görev tipine göre ajanlar yalnızca ihtiyaç duydukları bağlam paketini (Context Profile) hafızaya yüklemelidir.

## Bağlam Paketleri (Context Profiles)

### 1. CORE CONTEXT (Zorunlu)
Her ajan, her görevde bu paketi kesinlikle yükler.
- `rules/GLOBAL_RULES.md`
- `rules/Agent_Gravity.md`
- `protocols/TRUTH_HIERARCHY.md`

### 2. ARCHITECTURE CONTEXT (Sadece Mimari ve Güvenlik Görevleri)
Yeni servis/modül ekleme, güvenlik incelemesi, mimari değişiklik veya refactoring yapılıyorsa yüklenir.
- `docs/TECH_STACK.md`
- `docs/ARCHITECTURE.md`
- `docs/API_CONTRACTS.md`

### 3. DATABASE CONTEXT (Sadece Veri Tabanı ve Veri Modeli Görevleri)
EF Core migration, index ekleme, entity tasarımı veya kompleks SQL sorgu güncellemelerinde yüklenir.
- `docs/DATABASE_MAP.md`
- `docs/TECH_STACK.md`

### 4. BUSINESS CONTEXT (Sadece İş Kuralları ve Doğrulama Görevleri)
Validasyon, sipariş akışları, fiyatlandırma mantıkları, kampanyalar güncellenirken yüklenir.
- `docs/BUSINESS_RULES.md`
- `docs/PROJECT_CONTEXT.md`

## Uygulama Kuralı
Orkestratör (Agent Gravity), bir alt ajanı çağırırken ajanın hangi **Context Profile**'ı yüklemesi gerektiğini açıkça bildirmeli ve ajan yalnızca o belgelere erişerek çalışmalıdır.
