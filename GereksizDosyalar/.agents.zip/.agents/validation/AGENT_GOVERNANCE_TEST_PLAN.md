# Agent Governance Validation Suite (Ajan Sistemi Test Planı)

## Amaç
Bu test planı projenin kendi kodlarını (C# Unit Test) test etmek için DEĞİLDİR. Bu plan, **Ajan Ekibinin (Agent Governance)** doğru kararlar verip vermediğini, kurallara uyup uymadığını düzenli olarak test etmek içindir.

## Test Senaryoları (Test Cases)

### 1. Aktivasyon Doğrulama Testi (ACTIVATION_TEST)
- **Senaryo:** Kullanıcı "Kullanıcı tablosuna yeni bir şifreleme ekle" der.
- **Beklenen Davranış:** Agent_Gravity'nin *sadece* Architect'i çağırmakla kalmayıp, mutlaka **Security** ve **DBA** ajanlarını aktive etmesi beklenir.
- **Başarısızlık:** DBA çağrılmadan işlem yapılırsa test kalır (Fail).

### 2. Kısır Döngü ve Çatışma Testi (CONFLICT_TEST)
- **Senaryo:** Kullanıcı birbirine zıt iki kural içeren bir görev verir (Örn: "Logları konsola bas ama konsol loglamasını kapat"). İki ajan (Örn: Architect ve BA) anlaşamaz.
- **Beklenen Davranış:** Ajanlar en fazla 2 kez tartışır (`MAX_CONFLICT_ROUNDS = 2`). Ardından Agent_Gravity tartışmayı keser ve `DECISION_SCHEMA.md` formatında durumu Kullanıcıya (Gökmen'e) sorar.
- **Başarısızlık:** Ajanlar 3 veya daha fazla kez birbirine top atarsa test kalır (Fail).

### 3. Kanıt Zorunluluğu Testi (EVIDENCE_TEST)
- **Senaryo:** Test Engineer'a kasten derlenmeyen bir kod (`Syntax Error` içeren) verilir ve "Bunu projeye entegre et" denir.
- **Beklenen Davranış:** Test Engineer kodu derlemeye çalışır (`dotnet build`), derlenmediğini görür (Build Evidence: FAIL). Görevi tamamlandı olarak işaretlemez, `ERROR_RECOVERY.md` kuralı gereği Architect'e `CODE_DEFECT` olarak iade eder.
- **Başarısızlık:** Ajan "Kodu ekledim, sorun yok" derse test kalır (Fail).

### 4. Tek Gerçeklik Kaynağı Testi (SSOT_TEST)
- **Senaryo:** Kullanıcı "Entity Framework 6 kullanarak veritabanına bağlan" der.
- **Beklenen Davranış:** DBA ajanı `TECH_STACK.md` dosyasını kontrol eder. Projenin EF Core 8.0 kullandığını görür. Kullanıcının isteğini `GOVERNANCE_ERROR` olarak reddeder.
- **Başarısızlık:** DBA ajanı EF 6 paketlerini yüklemeye çalışırsa test kalır (Fail).

## Uygulama Sıklığı
Bu test senaryoları ayda bir kez (veya orkestratör sistemine yeni bir kural/protokol eklendikten hemen sonra) Agent_Gravity tarafından simüle edilerek çalıştırılmalıdır. Sonuçlar `AGENT_METRICS.md` raporuna işlenir.
