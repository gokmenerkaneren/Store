# Decision Package Schema (Karar Paketi Şablonu)

## Kullanım Amacı
Ajanlar arasında fikir ayrılığı çıktığında (Conflict) veya Kullanıcı Onayı (Decision Gate) gereken kritik bir mimari karar alındığında, Kullanıcıya (Gökmen) sorunun standart, temiz ve analitik bir yolla sunulması gerekir. Bu şablon bu sunumu düzenler.

## Şablon Formatı

Ajan Orkestratörü (Agent_Gravity) Kullanıcıya danışırken tam olarak aşağıdaki yapıyı kullanmalıdır:

```markdown
### ⚠️ KARAR KAPISI (DECISION GATE) - [Karar Konusu Kısa Başlık]

**Durum (Context):**
[Problemin 1-2 cümlelik kısa ve net tanımı. Örn: Sipariş servisine stok kontrolü eklenecek ancak bunun nasıl yapılacağı tartışılıyor.]

**Uzman Görüşleri (Conflict / Deliberation):**
- 🛡️ **[Ajan 1 Rolü] Diyor ki:** [Argümanı ve gerekçesi. Örn: "DBA: Ayrı tablo açalım, performans iyi olur."]
- 🏗️ **[Ajan 2 Rolü] Diyor ki:** [Karşıt veya farklı argümanı. Örn: "Architect: Hayır, event-driven yapalım, mikroservis kuralı ihlal edilmesin."]

**Riskler ve Etki (Risks & Impact):**
- Seçenek 1'in riski: [...]
- Seçenek 2'nin riski: [...]

**Orkestratör Analizi & Tavsiye (Gravity's Recommendation):**
[Tüm projenin büyük resmi düşünüldüğünde orkestratörün (sizin) teknik olarak önerdiğiniz çözüm ve nedeni.]

**Karar Seçenekleri (Seçiminizi Belirtin):**
1. [Seçenek 1 Kısa Tanımı]
2. [Seçenek 2 Kısa Tanımı]
3. [Diğer bir yol izle]
```

## Zorunluluklar
- Orkestratör taraf tutmak zorunda değildir ama `BUSINESS_RULES.md` veya `ARCHITECTURE.md` dosyalarına hangisi daha uygunsa onu **Tavsiye** olarak belirtmek zorundadır.
- Kullanıcıya boş bir "Ne yapalım?" sorusu sorulamaz, her zaman seçenekler (Options) üretilmelidir.
