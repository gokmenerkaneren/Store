# APPROVAL POLICY

## Otomatik ilerleyebilen işler

- Dokümantasyon typo/düzenleme
- Düşük riskli refactoring
- Test ekleme
- L0/L1 sınıfındaki, geri alınabilir değişiklikler

## Approval gerektiren işler

- Yeni mikroservis veya bounded context
- Servisler arası contract değişikliği
- Database destructive migration
- Kimlik doğrulama/yetkilendirme mimarisi değişikliği
- Hassas veri modelinde değişiklik
- Payment mimarisi kararı
- Production etkili konfigürasyon değişikliği

## Approval kaydı

Onay gerektiren karar `ADR` veya `Decision Gate` kaydı ile izlenir. Kullanıcı onayı alınmadan kritik değişiklik uygulanmaz.
