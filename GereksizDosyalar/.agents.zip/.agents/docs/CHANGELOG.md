# CHANGELOG — VERSİYON VE DEĞİŞİKLİK GEÇMİŞİ
# ══════════════════════════════════════════════════
# Proje genelinde sprint bazlı geliştirilen modüllerin ve düzeltilen hataların listesi.

---

## [Unreleased]
### Added
- Ödeme ve Bildirim stratejileri planlama aşamasında.

---

## [v1.2.0] - 2026-10-03
### Added
- `Store.Rental` modülü e-ticaret odaklı kiralama kuralları ile yapılandırıldı.
- `Ajan Sistemi` güncellendi, hafıza dosyaları tam kapsamlı olarak aktif edildi (Business Rules, Database Map, Tech Stack, API Contracts).

### Changed
- Sipariş ID'leri (Orderings) GUID formatına güncellendi.
- `BUSINESS_RULES.md` e-ticaret tabanlı stok takibini yönetecek şekilde güncellendi.

### Fixed
- SSL bypass sınırlandırma (sadece #if DEBUG) tamamlandı.
- Kimlik bilgilerinin appsettings üzerinde plaintext saklanma açığı giderildi.
- tempkey.jwk dosyası git ignore'a eklenerek repo güvenliği sağlandı.

---

## [v1.1.0] - 2026-09-16
### Added
- `Store.Favorite` mikroservisi oluşturuldu ve kullanıma hazır.
- Instagram akışı medya entegrasyonu tamamlandı.

### Changed
- BaseEntity kalıtımı tüm domain katmanlarında standartlaştırıldı.

> **Güncelleme Kuralı:** Geliştirme döngüsü sonunda önemli güncellemeler buraya manuel olarak işlenmelidir.
