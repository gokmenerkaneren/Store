# IMPLEMENTATION ROADMAP

## Phase 0 — Baseline

Mevcut `.agents` ve proje docs yedeklenir; gerçek durum çıkarılır.

## Phase 1 — Governance Foundation

Rules + protocols + templates devreye alınır.

## Phase 2 — Specialist Skills

Beş uzman skill'i gerçek proje kurallarıyla doğrulanır.

## Phase 3 — Dry Run

Kod değiştirmeden örnek görevler üzerinde çalıştırılır.

## Phase 4 — Controlled Production

L0/L1 görevlerle başlanır; L2/L3 approval gate altında tutulur.

## Phase 5 — Continuous Governance

Weekly review + agent evaluation + documentation synchronization.
